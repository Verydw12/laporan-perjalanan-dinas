<?php 
include "../conn/conn.php";
$id = $_GET['id'];
mysqli_query($conn,"DELETE FROM laporan_pengawasan WHERE id_pengawasan='$id'");
echo "<script>window.location.href='index.php?page=riwayat_laporan_pengawasan';</script>'";
exit;
?>