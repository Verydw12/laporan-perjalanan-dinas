

<div class="row">
    <div class="col-xl-9 mx-auto">
        <div class="card border-top border-0 border-4">
            <div class="card-body">
                <div class="border p-4 rounded">
                    <div class="card-title d-flex align-items-center">
                        <div><i class="bx bxs-user me-1 font-22"></i></div>
                        <h5 class="mb-0">Laporan Pengawasan</h5>
                    </div>
                    <hr />

                    <!-- Notifikasi jika sukses -->
                    <?php if (isset($_GET['status']) && $_GET['status'] == 'success') { ?>
                        <div class="mb-3">
                            <button type="button" 
                                    class="btn btn-success px-2" 
                                    onClick="window.location.href = 'index.php?page=riwayat_laporan_pengawasan';">
                                <i class='bx bx-check mr-1'></i> Berhasil Mengirimkan Laporan Pengawasan, Check Riwayat 
                            </button>
                        </div>
                    <?php } ?>

                </div>
            </div>
        </div>
    </div>
</div>
