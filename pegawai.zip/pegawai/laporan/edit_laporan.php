<!--breadcrumb-->
<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
    <div class="breadcrumb-title pe-3">Edit Laporan</div>
    <div class="ps-3">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item"><a href="index.php?page=dashboard"><i class="bx bx-home-alt"></i></a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Edit Laporan</li>
            </ol>
        </nav>
    </div>
</div>
<!--end breadcrumb-->
<?php
include "../conn/conn.php";
$id_laporan = $_GET['id'];
$data_laporan = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM laporan_kegiatan WHERE id_laporan = '$id_laporan'"));
if (isset($_POST['submit'])) {
    $judul = $_POST['judul'];
    $lokasi = $_POST['lokasi'];
    $tgl = $_POST['tgl'];
    $mytextarea = $_POST['mytextarea'];
    $pejabat_tempat = $_POST['pejabat_tempat'];

    // Proses upload foto
    $foto_names = [];
    if (!empty($_FILES['foto_kegiatan']['name'][0])) {
        $total_files = count($_FILES['foto_kegiatan']['name']);
        $max_files = min($total_files, 5);
        for ($i = 0; $i < $max_files; $i++) {
            $tmp_name = $_FILES['foto_kegiatan']['tmp_name'][$i];
            $name = time() . '_' . basename($_FILES['foto_kegiatan']['name'][$i]);
            $target = "../uploads/" . $name;
            if (move_uploaded_file($tmp_name, $target)) {
                $foto_names[] = $name;
            }
        }
    }
    // Jika tidak upload baru, gunakan yang lama
    if (count($foto_names) > 0) {
        $foto_kegiatan = implode(',', $foto_names);
    } else {
        $foto_kegiatan = $data_laporan['foto_kegiatan'];
    }

    $created_at = date('Y-m-d');
    mysqli_query($conn,"UPDATE laporan_kegiatan SET judul_laporan='$judul',lokasi='$lokasi',tgl='$tgl',isi='$mytextarea',created_at='$created_at', pejabat_tempat='$pejabat_tempat', foto_kegiatan='$foto_kegiatan' WHERE id_laporan='$id_laporan'");
    echo "<script>window.location.href='index.php?page=riwayat_laporan';</script>";
}
?>
<div class="row">
    <div class="col-xl-9 mx-auto">
        <div class="card border-top border-0 border-4 ">
            <div class="card-body">
                <div class="border p-4 rounded">
                    <div class="card-title d-flex align-items-center">
                        <div><i class="bx bxs-user me-1 font-22"></i>
                        </div>
                        <h5 class="mb-0">Laporan <?= ucwords($data_laporan['judul_laporan']) ?></h5>
                    </div>
                    <hr />
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="row mb-3">
                            <label for="judul" class="col-sm-3 col-form-label">Nama Petugas</label>
                            <div class="col-sm-9">
                                <textarea name="judul" class="form-control" rows="2" required><?= $data_laporan['judul_laporan'] ?></textarea>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="Lokasi Kegiatan" class="col-sm-3 col-form-label">Tujuan</label>
                            <div class="col-sm-9">
                                <input type="text" name="lokasi" value="<?= $data_laporan['lokasi'] ?>" class="form-control" id="Lokasi Kegiatan" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="tgl" class="col-sm-3 col-form-label">Jadwal</label>
                            <div class="col-sm-9">
                                <input type="date" class="form-control" name="tgl" value="<?= date('Y-m-d', strtotime($data_laporan['tgl'])); ?>">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="mytextarea" class="col-sm-3 col-form-label">Uraian Kegiatan</label>
                            <div class="col-sm-9">
                                <textarea id="mytextarea" name="mytextarea"><?= $data_laporan['isi'] ?></textarea>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Pejabat dan Tempat yang Dikunjungi</label>
                            <div class="col-sm-9">
                                <textarea name="pejabat_tempat" class="form-control" rows="2" required><?= $data_laporan['pejabat_tempat'] ?></textarea>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Foto Kegiatan</label>
                            <div class="col-sm-9">
                                <input type="file" name="foto_kegiatan[]" class="form-control" multiple accept="image/*">
                                <small class="text-muted">Upload minimal 1, maksimal 5 foto. Jika tidak diubah, foto lama tetap digunakan.</small>
                                <?php if (!empty($data_laporan['foto_kegiatan'])): ?>
                                    <div class="mt-2">
                                        <strong>Foto lama:</strong><br>
                                        <?php foreach (explode(',', $data_laporan['foto_kegiatan']) as $foto): ?>
                                            <img src="../uploads/<?= $foto ?>" alt="Foto Kegiatan" style="max-width:100px;max-height:80px;margin-right:5px;">
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            <label class="col-sm-3 col-form-label"></label>
                            <div class="col-sm-9">
                                <input type="submit" name="submit" value="Perbaharui Laporan" class="btn btn-primary px-5">
                                <a href="index.php?page=riwayat_laporan" class="btn btn-secondary px-4">Batal</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>