<!--breadcrumb-->
<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
    <div class="breadcrumb-title pe-3">Laporan</div>
    <div class="ps-3">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item">
                    <a href="index.php?page=dashboard"><i class="bx bx-home-alt"></i></a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                    List Laporan Saya
                </li>
            </ol>
        </nav>
    </div>
</div>
<!--end breadcrumb-->

<h6 class="mb-0 text-uppercase">Laporan Saya</h6>
<hr />

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="5%"><center>No</center></th>
                        <th><center>Judul Laporan</center></th>
                        <th><center>Lokasi</center></th>
                        <th><center>Kode Pembebanan</center></th>
                        <th><center>Tanggal</center></th>
                        <th><center>Action</center></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // fungsi format tanggal Indonesia
                    function tgl_indo($tanggal){
                        $bulan = array(
                            1 => 'Januari','Februari','Maret','April','Mei','Juni',
                            'Juli','Agustus','September','Oktober','November','Desember'
                        );
                        $pecahkan = explode('-', $tanggal);
                        return $pecahkan[2] . ' ' . $bulan[(int)$pecahkan[1]] . ' ' . $pecahkan[0];
                    }

                    include "../conn/conn.php";
                    $no = 1;
                    $id_staff = $_SESSION['id_staff'];
                    $role = $_SESSION['tipe']; // admin / pegawai

                    // Query sesuai role
                    if ($role == "admin") {
                        $query = mysqli_query($conn, "SELECT * FROM laporan_pencacahan ORDER BY id_pencacahan DESC");
                    } else {
                        $query = mysqli_query($conn, "SELECT * FROM laporan_pencacahan WHERE created_by = '$id_staff' ORDER BY id_pencacahan DESC");
                    }

                    while ($data = mysqli_fetch_array($query)) { ?>
                        <tr>
                            <td><center><?= $no++ ?></center></td>
                            <td><center><b><?= ucwords($data['nama_petugas']) ?></b></center></td>
                            <td><center><?= ucwords($data['lokasi']) ?></center></td>
                            <td><center><?= ucwords($data['kode_pengawasan']) ?></center></td>
                            <td><center><?= tgl_indo(date('Y-m-d', strtotime($data['tgl']))) ?></center></td>
                            <td>
                                <center>
                                    <a href="index.php?page=edit_laporan_pencacahan&id=<?= $data['id_pencacahan']; ?>" 
                                        style="color: blue; text-decoration: none;">
                                        <i class="bx bx-edit"></i> Edit
                                    </a> 
                                    | 
                                    <a href="index.php?page=delete_laporan_pencacahan&id=<?= $data['id_pencacahan']; ?>" 
                                        style="color: red; text-decoration: none;" 
                                        onclick="return confirm('Yakin ingin menghapus laporan ini?')">
                                        <i class="bx bx-trash"></i> Hapus
                                    </a>
                                    |
                                    <a href="laporan/print_laporan_pencacahan.php?id=<?= $data['id_pencacahan']; ?>" 
                                        style="color: green; text-decoration: none;" target="_blank">
                                        <i class="bx bx-printer"></i> Print
                                    </a>
                                </center>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
