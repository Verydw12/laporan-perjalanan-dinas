<?php 
include "../conn/conn.php";
$id = $_GET['id'];
mysqli_query($conn,"DELETE FROM laporan_pencacahan WHERE id_pencacahan='$id'");
echo "<script>window.location.href='index.php?page=riwayat_laporan_pencacahan';</script>'";
exit;
?>