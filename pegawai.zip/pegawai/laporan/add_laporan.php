<?php
if (isset($_POST['submit'])) {
    include "../conn/conn.php";

    // Ambil data dari form
    $judul      = $_POST['judul'];
    $lokasi     = $_POST['lokasi'];
    $tgl        = $_POST['tgl'];
    $kode_konsultasi        = $_POST['kode_konsultasi'];
    $uraian_kegiatan        = $_POST['uraian_kegiatan'];
    $mytextarea = $_POST['mytextarea'];
    $pejabat_tempat = $_POST['pejabat_tempat'];

    // Ambil data session user
    $created_by = $_SESSION['id_staff'];

    // Tanggal otomatis
    date_default_timezone_set('Asia/Jakarta');
    $created_at = date('Y-m-d');


    // Proses upload foto
    $foto_names = [];
    if (!empty($_FILES['foto_kegiatan']['name'][0])) {
        $total_files = count($_FILES['foto_kegiatan']['name']);
        $max_files = min($total_files, 5); // maksimal 5 foto
        for ($i = 0; $i < $max_files; $i++) {
            $tmp_name = $_FILES['foto_kegiatan']['tmp_name'][$i];
            $name = time() . '_' . basename($_FILES['foto_kegiatan']['name'][$i]);
            $target = "../uploads/" . $name;
            if (move_uploaded_file($tmp_name, $target)) {
                $foto_names[] = $name;
            }
        }
    }
    $foto_kegiatan = implode(',', $foto_names);

    // Simpan ke DB (tambahkan field foto_kegiatan)
    $sql = "INSERT INTO laporan_kegiatan (kode_konsultasi, uraian_kegiatan, judul_laporan, lokasi, tgl, isi, created_by, created_at, foto_kegiatan, pejabat_tempat) 
            VALUES ('$kode_konsultasi','$uraian_kegiatan','$judul', '$lokasi', '$tgl', '$mytextarea', '$created_by', '$created_at', '$foto_kegiatan', '$pejabat_tempat')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        // redirect balik ke halaman dengan notifikasi
        echo "<script>
            window.location.href='index.php?page=laporan&status=success';
        </script>";
    } else {
        echo "<script>alert('Gagal menyimpan data');</script>";
    }
}
?>

<div class="row">
    <div class="col-xl-9 mx-auto">
        <div class="card border-top border-0 border-4">
            <div class="card-body">
                <div class="border p-4 rounded">
                    <div class="card-title d-flex align-items-center">
                        <div><i class="bx bxs-user me-1 font-22"></i></div>
                        <h5 class="mb-0">Form Laporan Konsultasi</h5>
                    </div>
                    <hr />

                    <!-- Notifikasi jika sukses -->
                    <?php if (isset($_GET['status']) && $_GET['status'] == 'success') { ?>
                        <div class="mb-3">
                            <button type="button" 
                                    class="btn btn-success px-2" 
                                    onClick="window.location.href = 'index.php?page=riwayat_laporan';">
                                <i class='bx bx-check mr-1'></i> Laporan berhasil disimpan, cek Riwayat
                            </button>
                        </div>
                    <?php } ?>

                    <!-- Form input -->
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Nama Petugas</label>
                            <div class="col-sm-9">
                                <textarea name="judul" class="form-control" rows="2" placeholder="1. Nama Petugas 1&#10;2. Nama Petugas 2" required style="resize:vertical; min-height:40px; max-height:80px;"></textarea>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Tujuan</label>
                            <div class="col-sm-9">
                                <input type="text" name="lokasi" class="form-control" placeholder="Tujuan" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Jadwal</label>
                            <div class="col-sm-9">
                                <input type="date" class="form-control" name="tgl" value="<?php echo date('Y-m-d'); ?>">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Kode Pembebanan Anggaran</label>
                            <div class="col-sm-9">
                                <input type="text" name="kode_konsultasi" class="form-control" placeholder="kode pembebanan anggaran" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Uraian Singkat Kegiatan</label>
                            <div class="col-sm-9">
                                <textarea name="uraian_kegiatan" class="form-control" rows="2" placeholder="" required style="resize:vertical; min-height:40px; max-height:80px;"></textarea>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Uraian Kegiatan</label>
                            <div class="col-sm-9">
                                <textarea id="mytextarea" name="mytextarea"></textarea>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Pejabat dan Tempat yang Dikunjungi</label>
                            <div class="col-sm-9">
                                <textarea name="pejabat_tempat" class="form-control" rows="2" placeholder="1. Nama Pejabat - Tempat&#10;2. Nama Pejabat - Tempat" required style="resize:vertical; min-height:40px; max-height:80px;"></textarea>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Foto Kegiatan</label>
                            <div class="col-sm-9">
                                <input type="file" name="foto_kegiatan[]" class="form-control" multiple accept="image/*">
                                <small class="text-muted">Upload minimal 1, maksimal 5 foto.</small>
                            </div>
                        </div>
                        <div class="row">
                            <label class="col-sm-3 col-form-label"></label>
                            <div class="col-sm-9">
                                <input type="submit" name="submit" value="Kirim Laporan" class="btn btn-primary px-5">
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
