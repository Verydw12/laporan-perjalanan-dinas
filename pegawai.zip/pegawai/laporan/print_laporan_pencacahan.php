<?php
require_once '../../vendor/autoload.php';
include "../../conn/conn.php";

use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\IOFactory;

if (ob_get_length()) ob_end_clean();

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($id <= 0) die("ID laporan tidak valid");

$query = mysqli_query($conn, "SELECT * FROM laporan_pencacahan WHERE id_pencacahan='$id'");
$data = mysqli_fetch_assoc($query);
if (!$data) die("Data laporan tidak ditemukan");

// ambil staff
$id_staff = $data['created_by'];
$q_staff = mysqli_query($conn, "SELECT nama FROM staff WHERE id_staff='$id_staff'");
$staff = mysqli_fetch_assoc($q_staff);
$nama_pembuat = $staff ? $staff['nama'] : "Unknown";

// format nama file dari kode pembebanan anggaran
$kode_anggaran = isset($data['kode_anggaran']) ? $data['kode_anggaran'] : $data['kode_pengawasan'];
$nama_file = preg_replace('/[^A-Za-z0-9_\-]/', '_', $kode_anggaran) . ".docx";

// buat dokumen
$phpWord = new PhpWord();
$section = $phpWord->addSection([
    'marginTop' => 567,    // 0.5 inch
    'marginBottom' => 567,
    'marginLeft' => 567,
    'marginRight' => 567
]);

// style
$tableStyle = [
    'borderSize' => 6, 
    'borderColor' => '000000', 
    'cellMargin' => 80,
    'width' => 100 * 50
];
$cellStyle = ['valign' => 'center'];
$cellStyleTop = ['valign' => 'top'];
$textBold = ['bold' => true, 'size' => 10];
$textNormal = ['size' => 10];
$textCenter = ['bold' => true, 'size' => 12];
$highlight = ['bgColor' => 'FFFF00', 'size' => 10];
$centerAlign = ['alignment' => 'center'];

// Buat satu tabel utama untuk seluruh dokumen
$phpWord->addTableStyle('TabelUtama', $tableStyle);
$mainTable = $section->addTable('TabelUtama');

// BARIS 1: JUDUL
$mainTable->addRow(800);
$titleCell = $mainTable->addCell(10000, ['gridSpan' => 4, 'valign' => 'center']);
$titleCell->addText("LAPORAN PERJALANAN DINAS", $textCenter, $centerAlign);

// BARIS 2: Header A. Umum
$mainTable->addRow(400);
$headerCell = $mainTable->addCell(10000, ['gridSpan' => 4, 'valign' => 'center']);
$headerCell->addText("A. Umum", $textBold, $centerAlign);

// Ambil nama petugas dari field nama_petugas
$nama_petugas_list = [];
if (!empty($data['nama_petugas'])) {
    $nama_petugas_list = preg_split('/\r\n|\r|\n/', $data['nama_petugas']);
}

// BARIS 3: Data bagian A - Baris 1
$mainTable->addRow(1200);
// Kolom 1: Nama Petugas
$cell1 = $mainTable->addCell(2000, $cellStyleTop);
$cell1->addText("1.Nama Petugas", $textBold);

// Kolom 2: Data Nama Petugas
$cell2 = $mainTable->addCell(3000, $cellStyleTop);
if (count($nama_petugas_list) > 0) {
    foreach ($nama_petugas_list as $nama_petugas) {
        if (!empty(trim($nama_petugas))) {
            $cell2->addText(trim($nama_petugas), [], $highlight);
            $cell2->addTextBreak();
        }
    }
}

// Kolom 3: Program yang Membiayai
$cell3 = $mainTable->addCell(2000, $cellStyleTop);
$cell3->addText("4.Program Yang Membiayai", $textBold);

// Kolom 4: Data Program Pembiaya
$cell4 = $mainTable->addCell(3000, $cellStyleTop);
$program_pembiaya = isset($data['program_pembiaya']) ? $data['program_pembiaya'] : "-";
$cell4->addText($program_pembiaya, [], $highlight);

// BARIS 4: Data bagian A - Baris 2
$mainTable->addRow(1000);
// Kolom 1: Tujuan
$cell1 = $mainTable->addCell(2000, $cellStyle);
$cell1->addText("2.Tujuan", $textBold);

// Kolom 2: Data Tujuan
$cell2 = $mainTable->addCell(3000, $cellStyle);
$cell2->addText($data['lokasi'], [], $highlight);

// Kolom 3: Kode Pembebanan
$cell3 = $mainTable->addCell(2000, $cellStyleTop);
$cell3->addText("5.Kode Pembebanan Anggaran", $textBold);

// Kolom 4: Data Kode
$cell4 = $mainTable->addCell(3000, $cellStyle);
$kode_anggaran = isset($data['kode_anggaran']) ? $data['kode_anggaran'] : $data['kode_pengawasan'];
$cell4->addText($kode_anggaran, [], $highlight);

// BARIS 5: Data bagian A - Baris 3
$mainTable->addRow(1000);
// Kolom 1: Jadwal
$cell1 = $mainTable->addCell(2000, $cellStyle);
$cell1->addText("3.Tanggal", $textBold);

// Kolom 2: Data Jadwal
$cell2 = $mainTable->addCell(3000, $cellStyle);
// Format tanggal ke bahasa Indonesia
$bulan = [
    '01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April',
    '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus',
    '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
];
$hari = [
    'Sunday' => 'Minggu', 'Monday' => 'Senin', 'Tuesday' => 'Selasa',
    'Wednesday' => 'Rabu', 'Thursday' => 'Kamis', 'Friday' => 'Jumat', 'Saturday' => 'Sabtu'
];
$tanggal = date('Y-m-d', strtotime($data['tgl']));
$tgl_format = date('d', strtotime($tanggal));
$bulan_format = $bulan[date('m', strtotime($tanggal))];
$tahun_format = date('Y', strtotime($tanggal));
$tanggal_lengkap = $tgl_format . ' ' . $bulan_format . ' ' . $tahun_format;
$cell2->addText($tanggal_lengkap, [], $highlight);

// Kolom 3: Tanda Tangan
$cell3 = $mainTable->addCell(2000, $cellStyleTop);
$cell3->addText("6.Tanda Tangan Petugas", $textBold);

// Kolom 4: Data TTD
$cell4 = $mainTable->addCell(3000, $cellStyleTop);
if (count($nama_petugas_list) > 0) {
    $no = 1;
    foreach ($nama_petugas_list as $nama_petugas) {
        if (!empty(trim($nama_petugas))) {
            $cell4->addText($no . ".", [], $highlight);
            $cell4->addTextBreak();
            $no++;
        }
    }
} else {
    $cell4->addText("....................................", [], $highlight);
}

// BARIS 6: Header B. Uraian Kegiatan
$mainTable->addRow(400);
$headerB = $mainTable->addCell(10000, ['gridSpan' => 4, 'valign' => 'center']);
$headerB->addText("B. Uraian Kegiatan (Ringkasan Hasil)", $textBold, $centerAlign);

// BARIS 7: Sub-header untuk kegiatan
$mainTable->addRow(400);
// Kolom 1: Kegiatan
$cell1 = $mainTable->addCell(2000, $cellStyle);
$cell1->addText("1.Kegiatan", $textBold);

// Kolom 2: Data Kegiatan
$cell2 = $mainTable->addCell(2000, $cellStyle);
$cell2->addText($data['kegiatan'], [], $highlight);

// Kolom 3: Petugas
$cell3 = $mainTable->addCell(2000, $cellStyle);
$cell3->addText("2.Lokasi Pencacahan", $textBold);

// Kolom 4: Data Petugas
$cell4 = $mainTable->addCell(2000, $cellStyle);
$cell4->addText($data['lokasi_tujuan'], [], $highlight);

// BARIS 9: Tabel Uraian dan Hasil
$mainTable->addRow(400);
$headerUraian = $mainTable->addCell(10000, ['gridSpan' => 4, 'valign' => 'center']);

// Buat sub-tabel untuk uraian dan hasil
$subTable = $headerUraian->addTable([
    'borderSize' => 6, 
    'borderColor' => '000000',
    'cellMargin' => 40,
    'width' => 100 * 50
]);

// Header sub-tabel
$subTable->addRow(400);
$subTable->addCell(1000, $cellStyle)->addText("No", $textBold, $centerAlign);
$subTable->addCell(4000, $cellStyle)->addText("Uraian", $textBold, $centerAlign);
$subTable->addCell(4000, $cellStyle)->addText("Hasil", $textBold, $centerAlign);

// Isi data uraian dan hasil
$uraian_list = explode("\n", $data['uraian']);
$hasil_list = explode("\n", $data['hasil']);

for ($i = 0; $i < max(count($uraian_list), count($hasil_list)); $i++) {
    $subTable->addRow(800);
    $subTable->addCell(1000, $cellStyle)->addText(($i + 1), [], $highlight);
    
    $uraian = isset($uraian_list[$i]) ? trim($uraian_list[$i]) : "";
    $hasil = isset($hasil_list[$i]) ? trim($hasil_list[$i]) : "";
    
    $subTable->addCell(4000, $cellStyleTop)->addText($uraian, [], $highlight);
    $subTable->addCell(4000, $cellStyleTop)->addText($hasil, [], $highlight);
}

// BARIS 10: Foto dokumentasi
$mainTable->addRow(1200);
$fotoCell = $mainTable->addCell(10000, ['gridSpan' => 4, 'valign' => 'top']);
$fotoCell->addText("Foto Dokumentasi Kegiatan", $textBold);

// Tampilkan foto kegiatan jika ada
if (!empty($data['foto_kegiatan'])) {
    $foto_files = explode(',', $data['foto_kegiatan']);
    foreach ($foto_files as $foto) {
        $foto_path = "../../uploads/" . trim($foto);
        if (file_exists($foto_path)) {
            $fotoCell->addImage($foto_path, [
                'width' => 200,
                'height' => 150,
                'wrappingStyle' => 'inline' 
            ]);
            $fotoCell->addTextBreak();
        }
    }
}

// BARIS 11: Header C. Pejabat dan Tempat yang dikunjungi
$mainTable->addRow(400);
$headerC = $mainTable->addCell(10000, ['gridSpan' => 4, 'valign' => 'center']);
$headerC->addText("C. Pejabat dan Tempat yang dikunjungi", $textBold, $centerAlign);

// BARIS 12: Isi bagian C - dari input pejabat_tempat
$mainTable->addRow(800);
$contentC = $mainTable->addCell(10000, ['gridSpan' => 4, 'valign' => 'top']);

// Tampilkan list pejabat dan tempat sesuai input
$pejabat_tempat_list = [];
if (!empty($data['pejabat_tempat'])) {
    $pejabat_tempat_list = preg_split('/\r\n|\r|\n/', $data['pejabat_tempat']);
    foreach ($pejabat_tempat_list as $item) {
        if (!empty(trim($item))) {
            $contentC->addText(trim($item), [], $highlight);
            $contentC->addTextBreak();
        }
    }
}

// Output
header("Content-Description: File Transfer");
header('Content-Disposition: attachment; filename="' . $nama_file . '"');
header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Expires: 0');

$objWriter = IOFactory::createWriter($phpWord, 'Word2007');
$objWriter->save("php://output");
exit;