<?php
if (isset($_POST['submit'])) {
    include "../conn/conn.php";

    // Ambil data dari form
    $nama_pelaksana = $_POST['nama_pelaksana'];
    $nomor_surat    = $_POST['nomor_surat'];
    $tempat_tujuan  = $_POST['tempat_tujuan'];

    // Tanggal & hari otomatis
    date_default_timezone_set('Asia/Jakarta');
    $tanggal_form = date('Y-m-d');

    // mapping hari ke bahasa Indonesia
    $hari_array = [
        'Sunday'    => 'Minggu',
        'Monday'    => 'Senin',
        'Tuesday'   => 'Selasa',
        'Wednesday' => 'Rabu',
        'Thursday'  => 'Kamis',
        'Friday'    => 'Jumat',
        'Saturday'  => 'Sabtu'
    ];

    $hari = $hari_array[date('l')];
    
    // Simpan ke DB
    $sql = "INSERT INTO form (nama_pelaksana, nomor_surat, tempat_tujuan, hari, tanggal_form, created_by) 
        VALUES ('$nama_pelaksana', '$nomor_surat', '$tempat_tujuan', '$hari', '$tanggal_form', '$id_staff')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        // redirect balik ke halaman dengan notifikasi
        echo "<script>
            window.location.href='index.php?page=form&status=success';
        </script>";
    } else {
        echo "<script>alert('Gagal menyimpan data');</script>";
    }
}
?>

<div class="row">
    <div class="col-xl-9 mx-auto">
        <div class="card border-top border-0 border-4">
            <div class="card-body">
                <div class="border p-4 rounded">
                    <div class="card-title d-flex align-items-center">
                        <div><i class="bx bxs-user me-1 font-22"></i></div>
                        <h5 class="mb-0">Form Bukti Kehadiran SPD</h5>
                    </div>
                    <hr />

                    <!-- Notifikasi jika sukses -->
                    <?php if (isset($_GET['status']) && $_GET['status'] == 'success') { ?>
                        <div class="mb-3">
                            <button type="button" 
                                    class="btn btn-success px-2" 
                                    onClick="window.location.href = 'index.php?page=riwayat_laporan';">
                                <i class='bx bx-check mr-1'></i> Berhasil Mengirimkan Form, Check Riwayat 
                            </button>
                        </div>
                    <?php } ?>

                    <!-- Form input -->
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Pelaksana SPD</label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_pelaksana" class="form-control" placeholder="Nama Pelaksana" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Nomor Surat Tugas</label>
                            <div class="col-sm-9">
                                <input type="text" name="nomor_surat" class="form-control" placeholder="Nomor Surat" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Tempat Tujuan</label>
                            <div class="col-sm-9">
                                <input type="text" name="tempat_tujuan" class="form-control" placeholder="Tempat Tujuan" required>
                            </div>
                        </div>
                        <div class="row">
                            <label class="col-sm-3 col-form-label"></label>
                            <div class="col-sm-9">
                                <input type="submit" name="submit" value="Kirim Form" class="btn btn-primary px-5">
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
