<!--breadcrumb-->
<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
    <div class="breadcrumb-title pe-3">Form Bukti Pelaksanaan SPD</div>
    <div class="ps-3">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item">
                    <a href="index.php?page=dashboard"><i class="bx bx-home-alt"></i></a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                    List Form Bukti Pelaksanaan SPD
                </li>
            </ol>
        </nav>
    </div>
</div>
<!--end breadcrumb-->

<h6 class="mb-0 text-uppercase">Form Saya</h6>
<hr />

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="5%"><center>No</center></th>
                        <th><center>Pelaksana SPD</center></th>
                        <th><center>Nomor SPD</center></th>
                        <th><center>Tempat Tujuan</center></th>
                        <th><center>Hari</center></th>
                        <th><center>Tanggal</center></th>
                        <th><center>Action</center></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // fungsi untuk format tanggal Indo
                    function tgl_indo($tanggal){
                        $bulan = array(
                            1 => 'Januari','Februari','Maret','April','Mei','Juni',
                            'Juli','Agustus','September','Oktober','November','Desember'
                        );
                        $pecahkan = explode('-', $tanggal);
                        return $pecahkan[2] . ' ' . $bulan[(int)$pecahkan[1]] . ' ' . $pecahkan[0];
                    }

                    include "../conn/conn.php";
                    $no = 1;
                    $id_staff = $_SESSION['id_staff'];
                    $role = $_SESSION['tipe']; // "admin" atau "pegawai"

                    // Query sesuai role
                    if ($role == "admin") {
                        $sql = "SELECT * FROM form ORDER BY id_form DESC";
                    } else {
                        $sql = "SELECT * FROM form WHERE created_by = '$id_staff' ORDER BY id_form DESC";
                    }

                    // ambil data sesuai user login
                    $query = mysqli_query($conn, "SELECT * FROM form WHERE created_by = '$id_staff'");
                    while ($data = mysqli_fetch_array($query)) { ?>
                        <tr>
                            <td><center><?= $no++ ?></center></td>
                            <td><center><?= ucwords($data['nama_pelaksana']) ?></center></td>
                            <td><center><?= $data['nomor_surat'] ?></center></td>
                            <td><center><?= ucwords($data['tempat_tujuan']) ?></center></td>
                            <td><center><?= $data['hari'] ?></center></td>
                            <td><center><?= tgl_indo($data['tanggal_form']) ?></center></td>
                            <td>
                                <center>
                                    <a href="index.php?page=edit_form&id_form=<?= $data['id_form']; ?>" 
                                    style="color: blue; text-decoration: none;">
                                        <i class="bx bx-edit"></i> Edit
                                    </a> 
                                    | 
                                    <a href="index.php?page=delete_form&id_form=<?= $data['id_form']; ?>" 
                                    style="color: red; text-decoration: none;" 
                                    onclick="return confirm('Yakin ingin menghapus data ini?')">
                                        <i class="bx bx-trash"></i> Hapus
                                    </a>
                                    |
                                    <a href="form/print_form.php?id_form=<?= $data['id_form']; ?>" 
                                        style="color: green; text-decoration: none;" target="_blank">
                                        <i class="bx bx-printer"></i> Print
                                    </a>
                                </center>
                            </td>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
