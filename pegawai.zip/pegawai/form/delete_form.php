<?php 
include "../conn/conn.php";

if (isset($_GET['id_form'])) {
    $id_form = $_GET['id_form'];

    // eksekusi hapus
    $delete = mysqli_query($conn, "DELETE FROM form WHERE id_form='$id_form'");

    if ($delete) {
        echo "<script>alert('Data berhasil dihapus'); 
        window.location.href='index.php?page=riwayat_form';</script>";
    } else {
        echo "<script>alert('Gagal menghapus data'); 
        window.location.href='index.php?page=riwayat_form';</script>";
    }
} else {
    echo "<script>alert('ID tidak ditemukan'); 
    window.location.href='index.php?page=riwayat_form';</script>";
}
?>
