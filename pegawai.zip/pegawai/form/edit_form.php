<?php
include "../conn/conn.php";

// Ambil id_form dari URL
$id_form = $_GET['id_form'];

// Ambil data form berdasarkan id_form
$data_form = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM form WHERE id_form='$id_form'"));

if (isset($_POST['submit'])) {
    // Ambil data dari inputan
    $nama_pelaksana = $_POST['nama_pelaksana'];
    $nomor_surat    = $_POST['nomor_surat'];
    $tempat_tujuan  = $_POST['tempat_tujuan'];

    // Update ke database
    $sql = "UPDATE form SET 
                nama_pelaksana='$nama_pelaksana',
                nomor_surat='$nomor_surat',
                tempat_tujuan='$tempat_tujuan'
            WHERE id_form='$id_form'";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo "<script>
                alert('Data berhasil diperbaharui');
                window.location.href='index.php?page=riwayat_form';
              </script>";
    } else {
        echo "<script>alert('Gagal memperbaharui data');</script>";
    }
}
?>

<div class="row">
    <div class="col-xl-9 mx-auto">
        <div class="card border-top border-0 border-4">
            <div class="card-body">
                <div class="border p-4 rounded">
                    <div class="card-title d-flex align-items-center">
                        <div><i class="bx bxs-edit me-1 font-22"></i></div>
                        <h5 class="mb-0">Edit Form SPD</h5>
                    </div>
                    <hr />

                    <form action="" method="POST">
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Pelaksana SPD</label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_pelaksana" value="<?= $data_form['nama_pelaksana'] ?>" class="form-control" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Nomor Surat Tugas</label>
                            <div class="col-sm-9">
                                <input type="text" name="nomor_surat" value="<?= $data_form['nomor_surat'] ?>" class="form-control" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Tempat Tujuan</label>
                            <div class="col-sm-9">
                                <input type="text" name="tempat_tujuan" value="<?= $data_form['tempat_tujuan'] ?>" class="form-control" required>
                            </div>
                        </div>

                        <div class="row">
                            <label class="col-sm-3 col-form-label"></label>
                            <div class="col-sm-9">
                                <input type="submit" name="submit" value="Perbarui Form" class="btn btn-primary px-5">
                                <a href="index.php?page=riwayat_form" class="btn btn-secondary px-4">Batal</a>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
