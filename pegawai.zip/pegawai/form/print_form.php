<?php
require('../../fpdf/fpdf.php');
include "../../conn/conn.php";

if (!isset($_GET['id_form'])) { die("Data tidak ditemukan"); }
$id_form = $_GET['id_form'];

$q = mysqli_query($conn, "SELECT * FROM form WHERE id_form = '$id_form'");
$data = mysqli_fetch_array($q);
if (!$data) { die("Data tidak ditemukan di database"); }

// format tanggal Indonesia
function tgl_indo($tanggal){
    $bulan = [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    $p = explode('-', $tanggal);
    return $p[2].' '.$bulan[(int)$p[1]].' '.$p[0];
}

$pdf = new FPDF();
$pdf->AddPage();

// ===== Header Judul =====
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,10,'Form Bukti Kehadiran Pelaksanaan Perjalanan Dinas Jabatan',0,1,'C');
$pdf->Cell(0,10,'Dalam Kota sampai dengan 8 (delapan) jam',0,1,'C');
$pdf->Ln(5);

// ===== Info Atas =====
$pdf->SetFont('Arial','',11);
$pdf->Cell(50,8,'Pelaksana SPD',0,0);
$pdf->Cell(0,8,': '.ucwords($data['nama_pelaksana']),0,1);
$pdf->Cell(50,8,'Nomor Surat Tugas',0,0);
$pdf->Cell(0,8,': '.$data['nomor_surat'],0,1);
$pdf->Ln(5);

// ===== Tabel =====
$pdf->SetFont('Arial','B',10);
$leftX = $pdf->GetX();      // simpan margin kiri
$topY  = $pdf->GetY();

$h1 = 7;  // tinggi baris 1 (judul grup)
$h2 = 7;  // tinggi baris 2 (sub header)
$H  = $h1 + $h2;

// kolom kiri (rowspan)
$pdf->Cell(40,$H,'Tempat Tujuan',1,0,'C');
$pdf->Cell(30,$H,'Hari',1,0,'C');
$pdf->Cell(30,$H,'Tanggal',1,0,'C');

// grup kanan - baris 1
$xRight = $pdf->GetX();
$yRight = $pdf->GetY();
$pdf->Cell(90,$h1,'Pejabat/Petugas yang mengesahkan',1,0,'C');

// pindah ke baris sub header (di area kanan)
$pdf->SetXY($xRight, $yRight + $h1);

// sub kolom tanpa garis atas (hilangkan garis ke-3)
$pdf->Cell(30,$h2,'Nama','LRB',0,'C');
$pdf->Cell(30,$h2,'Jabatan','LRB',0,'C');

// untuk "Tanda Tangan & Stempel": gambar kotak sekali, teks pakai MultiCell tanpa border
$xTtd = $pdf->GetX();
$yTtd = $pdf->GetY();
$pdf->Rect($xTtd, $yTtd, 30, $h2);                 // bingkai
$pdf->MultiCell(30,3.5,"Tanda Tangan \n dan Stempel",0,'C');

// set kursor ke awal baris berikutnya (selesai header 2 tingkat)
$pdf->SetXY($leftX, $topY + $H);

// ===== Isi Tabel =====
$pdf->SetFont('Arial','',10);
$tinggi_baris = 25; // cukup untuk ruang tanda tangan

$pdf->Cell(40,$tinggi_baris,ucwords($data['tempat_tujuan']),1,0,'C');
$pdf->Cell(30,$tinggi_baris,$data['hari'],1,0,'C');
$pdf->Cell(30,$tinggi_baris,tgl_indo($data['tanggal_form']),1,0,'C');
$pdf->Cell(30,$tinggi_baris,'',1,0,'C'); // Nama pejabat
$pdf->Cell(30,$tinggi_baris,'',1,0,'C'); // Jabatan
$pdf->Cell(30,$tinggi_baris,'',1,1,'C'); // TTD & Stempel

$pdf->Output();
?>
