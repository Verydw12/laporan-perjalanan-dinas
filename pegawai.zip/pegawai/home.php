<?php
include "../conn/conn.php";
function tgl_indo($tanggal){
    $bulan = array (
        1 =>   'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    );
    $pecahkan = explode('-', $tanggal);
    return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
}
?>

<style>
/* Tambahan CSS untuk efek hover box */
.card-hover {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.card-hover:hover {
    transform: scale(1.05);
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
}
.card-title-big {
    font-size: 1.6rem; /* lebih besar */
    font-weight: bold;
    color: white;
    margin: 0;
}
</style>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-xl-2">
                        <a class="btn btn-primary mb-3 mb-lg-0"><i class='bx bxs-home-circle'></i>Dashboard</a>
                    </div>
                    <div class="col-lg-9 col-xl-10">
                        <form class="float-lg-end">
                            <div class="row row-cols-lg-auto g-2">
                                <div class="col-12">
                                    <h3><?= tgl_indo(date('Y-m-d')) ?></h3>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-12">
        <div class="card radius-10 shadow-sm">
            <div class="card-body text-center">
                <h2 class="mb-0">
                    Selamat Datang di Website <b>TransLog BPS Sleman</b>
                </h2>
            </div>
        </div>
    </div>
</div>

<div class="row row-cols-1 row-cols-sm-2 row-cols-md-2 g-4">
    <!-- Box Form -->
    <div class="col">
        <a href="index.php?page=add_form" style="text-decoration:none;">
            <div class="card radius-10 bg-primary bg-gradient h-100 card-hover">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <p class="card-title-big">Buat Form Pelaksanaan SPD</p>
                    </div>
                    <div class="text-white font-35"><i class='bx bx-spreadsheet'></i></div>
                </div>
            </div>
        </a>
    </div>

    <!-- Box Laporan -->
    <div class="col">
        <a href="index.php?page=add_laporan" style="text-decoration:none;">
            <div class="card radius-10 bg-primary bg-gradient h-100 card-hover">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <p class="card-title-big">Buat Laporan Konsultasi</p>
                    </div>
                    <div class="text-white font-35"><i class='bx bx-notepad'></i></div>
                </div>
            </div>
        </a>
    </div>
    <div class="col">
        <a href="index.php?page=add_laporan_pengawasan" style="text-decoration:none;">
            <div class="card radius-10 bg-primary bg-gradient h-100 card-hover">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <p class="card-title-big">Buat Laporan Pengawasan</p>
                    </div>
                    <div class="text-white font-35"><i class='bx bx-notepad'></i></div>
                </div>
            </div>
        </a>
    </div>
    <div class="col">
        <a href="index.php?page=add_laporan_pencacahan" style="text-decoration:none;">
            <div class="card radius-10 bg-primary bg-gradient h-100 card-hover">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <p class="card-title-big">Buat Laporan Pencacahan</p>
                    </div>
                    <div class="text-white font-35"><i class='bx bx-notepad'></i></div>
                </div>
            </div>
        </a>
    </div>
</div>
