<?php
require('../../fpdf/fpdf.php');
include "../../conn/conn.php";

if (!isset($_GET['id_form'])) { die("Data tidak ditemukan"); }
$id_form = $_GET['id_form'];

$q = mysqli_query($conn, "SELECT * FROM form WHERE id_form = '$id_form'");
$data = mysqli_fetch_array($q);
if (!$data) { die("Data tidak ditemukan di database"); }

// format tanggal Indonesia
function tgl_indo($tanggal){
    $bulan = [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    $p = explode('-', $tanggal);
    return $p[2].' '.$bulan[(int)$p[1]].' '.$p[0];
}

// Fungsi untuk menghitung tinggi yang dibutuhkan untuk MultiCell
function getMultiCellHeight($pdf, $w, $txt, $fontSize = 10) {
    $pdf->SetFont('Arial', '', $fontSize);
    
    // Hitung jumlah baris yang dibutuhkan
    $nb = 0;
    $lines = explode("\n", $txt);
    
    foreach($lines as $line) {
        $nb += $pdf->NbLines($w, $line);
    }
    
    return $nb * 5; // 5 adalah tinggi per baris
}

// Extend FPDF untuk NbLines function
class PDF extends FPDF {
    function NbLines($w, $txt) {
        $cw = &$this->CurrentFont['cw'];
        if($w == 0) $w = $this->w - $this->rMargin - $this->x;
        $wmax = ($w - 2 * $this->cMargin) * 1000 / $this->FontSize;
        $s = str_replace("\r", '', $txt);
        $nb = strlen($s);
        if($nb > 0 and $s[$nb-1] == "\n") $nb--;
        $sep = -1;
        $i = 0;
        $j = 0;
        $l = 0;
        $nl = 1;
        while($i < $nb) {
            $c = $s[$i];
            if($c == "\n") {
                $i++;
                $sep = -1;
                $j = $i;
                $l = 0;
                $nl++;
                continue;
            }
            if($c == ' ') $sep = $i;
            $l += $cw[$c];
            if($l > $wmax) {
                if($sep == -1) {
                    if($i == $j) $i++;
                } else {
                    $i = $sep + 1;
                }
                $sep = -1;
                $j = $i;
                $l = 0;
                $nl++;
            } else {
                $i++;
            }
        }
        return $nl;
    }
    
    // Function untuk membuat cell dengan auto height
    function MultiRow($data, $widths, $aligns = null, $minHeight = 10) {
        if($aligns == null) {
            $aligns = array_fill(0, count($data), 'L');
        }
        
        // Hitung tinggi maksimum yang dibutuhkan
        $maxHeight = $minHeight;
        for($i = 0; $i < count($data); $i++) {
            $cellHeight = $this->NbLines($widths[$i], $data[$i]) * 5;
            if($cellHeight > $maxHeight) {
                $maxHeight = $cellHeight;
            }
        }
        
        // Simpan posisi X dan Y
        $x = $this->GetX();
        $y = $this->GetY();
        
        // Gambar border untuk semua cell
        for($i = 0; $i < count($data); $i++) {
            $this->Rect($x, $y, $widths[$i], $maxHeight);
            $x += $widths[$i];
        }
        
        // Reset posisi dan isi dengan teks
        $x = $this->GetX();
        for($i = 0; $i < count($data); $i++) {
            $this->SetXY($x, $y);
            $this->MultiCell($widths[$i], 5, $data[$i], 0, $aligns[$i]);
            $x += $widths[$i];
        }
        
        // Pindah ke baris berikutnya
        $this->SetXY($this->GetX() - array_sum($widths), $y + $maxHeight);
        
        return $maxHeight;
    }
}

$pdf = new PDF();
$pdf->AddPage();

// ===== Header Judul =====
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,10,'Form Bukti Kehadiran Pelaksanaan Perjalanan Dinas Jabatan',0,1,'C');
$pdf->Cell(0,10,'Dalam Kota sampai dengan 8 (delapan) jam',0,1,'C');
$pdf->Ln(5);

// ===== Info Atas =====
$pdf->SetFont('Arial','',11);
$pdf->Cell(50,8,'Pelaksana SPD',0,0);
$pdf->Cell(0,8,': '.ucwords($data['nama_pelaksana']),0,1);
$pdf->Cell(50,8,'Nomor Surat Tugas',0,0);
$pdf->Cell(0,8,': '.$data['nomor_surat'],0,1);
$pdf->Ln(5);

// ===== Header Tabel =====
$pdf->SetFont('Arial','B',10);
$leftX = $pdf->GetX();
$topY  = $pdf->GetY();

$h1 = 7;  // tinggi baris 1 (judul grup)
$h2 = 7;  // tinggi baris 2 (sub header)
$H  = $h1 + $h2;

// kolom kiri (rowspan)
$pdf->Cell(40,$H,'Tempat Tujuan',1,0,'C');
$pdf->Cell(25,$H,'Hari',1,0,'C');
$pdf->Cell(35,$H,'Tanggal',1,0,'C');

// grup kanan - baris 1
$xRight = $pdf->GetX();
$yRight = $pdf->GetY();
$pdf->Cell(90,$h1,'Pejabat/Petugas yang mengesahkan',1,0,'C');

// pindah ke baris sub header (di area kanan)
$pdf->SetXY($xRight, $yRight + $h1);

// sub kolom
$pdf->Cell(30,$h2,'Nama','LRB',0,'C');
$pdf->Cell(30,$h2,'Jabatan','LRB',0,'C');

// untuk "Tanda Tangan & Stempel": gambar kotak sekali, teks pakai MultiCell
$xTtd = $pdf->GetX();
$yTtd = $pdf->GetY();
$pdf->Rect($xTtd, $yTtd, 30, $h2);
$pdf->MultiCell(30,3.5,"Tanda Tangan \n dan Stempel",0,'C');

// set kursor ke awal baris berikutnya
$pdf->SetXY($leftX, $topY + $H);

// ===== Isi Tabel dengan Auto Height =====
$pdf->SetFont('Arial','',10);

// Data untuk baris tabel
$tempat = ucwords($data['tempat_tujuan']);
$hari = $data['hari'];
$tanggal = tgl_indo($data['tanggal_form']);

// Array data dan lebar kolom
$rowData = [$tempat, $hari, $tanggal, '', '', ''];
$colWidths = [40, 25, 35, 30, 30, 30];
$colAligns = ['C', 'C', 'C', 'C', 'C', 'C'];

// Buat baris dengan tinggi otomatis (minimum 25 untuk ruang tanda tangan)
$pdf->MultiRow($rowData, $colWidths, $colAligns, 25);

$pdf->Output();
?>