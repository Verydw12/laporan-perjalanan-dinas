<?php
include "../conn/conn.php";
function tgl_indo($tanggal){
    $bulan = array (
        1 =>   'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    );
    $pecahkan = explode('-', $tanggal);
    
    // variabel pecahkan 0 = tanggal
    // variabel pecahkan 1 = bulan
    // variabel pecahkan 2 = tahun
 
    return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
}
?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-xl-2">
                        <a class="btn btn-primary mb-3 mb-lg-0"><i class='bx bxs-home-circle'></i>Dashboard</a>
                    </div>
                    <div class="col-lg-9 col-xl-10">
                        <form class="float-lg-end">
                            <div class="row row-cols-lg-auto g-2">
                                <div class="col-12">
                                    <h3><?= tgl_indo(date('Y-m-d')) ?></h3>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-12">
        <div class="card radius-10 shadow-sm">
            <div class="card-body text-center">
                <h2 class="mb-0">
                    Selamat Datang di Website <b>TransLog BPS Sleman</b>
                </h2>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Pegawai Terdaftar -->
    <div class="col-12 col-sm-6 col-md-4 col-lg-3">
        <div class="card radius-10 bg-primary bg-gradient h-100 card-hover shadow">
            <div class="card-body d-flex flex-column justify-content-between align-items-center text-center">
                <div class="mb-2">
                    <div class="text-white font-35 mb-2"><i class='bx bx-user'></i></div>
                    <p class="mb-0 text-white">Pegawai Terdaftar</p>
                </div>
                <h4 class="my-1 text-white">
                    <?php
                    // Hanya hitung pegawai dengan role 'pegawai'
                    $data_staff = mysqli_fetch_assoc(mysqli_query($conn, "SELECT count(*) as total FROM staff"));
                    echo $data_staff['total'];
                    ?>
                </h4>
            </div>
        </div>
    </div>
    <!-- Total Form -->
    <div class="col-12 col-sm-6 col-md-4 col-lg-3">
        <div class="card radius-10 bg-info bg-gradient h-100 card-hover shadow">
            <div class="card-body d-flex flex-column justify-content-between align-items-center text-center">
                <div class="mb-2">
                    <div class="text-white font-35 mb-2"><i class='bx bx-spreadsheet'></i></div>
                    <p class="mb-0 text-white">Total Form</p>
                </div>
                <h4 class="my-1 text-white">
                    <?php
                    $data_form = mysqli_fetch_assoc(mysqli_query($conn, "SELECT count(*) as total from form"));
                    echo $data_form['total'];
                    ?>
                </h4>
            </div>
        </div>
    </div>
    <!-- Total Laporan Konsultasi -->
    <div class="col-12 col-sm-6 col-md-4 col-lg-3">
        <div class="card radius-10 bg-success bg-gradient h-100 card-hover shadow">
            <div class="card-body d-flex flex-column justify-content-between align-items-center text-center">
                <div class="mb-2">
                    <div class="text-white font-35 mb-2"><i class='bx bx-message-square-detail'></i></div>
                    <p class="mb-0 text-white">Total Laporan Konsultasi</p>
                </div>
                <h4 class="my-1 text-white">
                    <?php
                    $data_laporan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT count(*) as total from laporan_kegiatan"));
                    echo $data_laporan['total'];
                    ?>
                </h4>
            </div>
        </div>
    </div>
    <!-- Total Laporan Pengawasan -->
    <div class="col-12 col-sm-6 col-md-4 col-lg-3">
        <div class="card radius-10 bg-warning bg-gradient h-100 card-hover shadow">
            <div class="card-body d-flex flex-column justify-content-between align-items-center text-center">
                <div class="mb-2">
                    <div class="text-white font-35 mb-2"><i class='bx bx-calendar-check'></i></div>
                    <p class="mb-0 text-white">Total Laporan Pengawasan</p>
                </div>
                <h4 class="my-1 text-white">
                    <?php
                    $data_laporan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT count(*) as total from laporan_pengawasan"));
                    echo $data_laporan['total'];
                    ?>
                </h4>
            </div>
        </div>
    </div>
    <!-- Total Laporan Pencacahan -->
    <div class="col-12 col-sm-6 col-md-4 col-lg-3">
        <div class="card radius-10 bg-danger bg-gradient h-100 card-hover shadow">
            <div class="card-body d-flex flex-column justify-content-between align-items-center text-center">
                <div class="mb-2">
                    <div class="text-white font-35 mb-2"><i class='bx bx-list-check'></i></div>
                    <p class="mb-0 text-white">Total Laporan Pencacahan</p>
                </div>
                <h4 class="my-1 text-white">
                    <?php
                    $data_laporan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT count(*) as total from laporan_pencacahan"));
                    echo $data_laporan['total'];
                    ?>
                </h4>
            </div>
        </div>
    </div>
</div>
