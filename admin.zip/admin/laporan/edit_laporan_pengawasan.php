<!--breadcrumb-->
<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
    <div class="breadcrumb-title pe-3">Edit Laporan</div>
    <div class="ps-3">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item"><a href="index.php?page=dashboard"><i class="bx bx-home-alt"></i></a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Edit Laporan</li>
            </ol>
        </nav>
    </div>
</div>
<!--end breadcrumb-->
<?php
include "../conn/conn.php";
$id_laporan = $_GET['id'];
$data_laporan = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM laporan_pengawasan WHERE id_pengawasan = '$id_laporan'"));

if (isset($_POST['submit'])) {
    $nama_petugas = $_POST['nama_petugas'];
    $lokasi = $_POST['lokasi'];
    $tgl = $_POST['tgl'];
    $program_pembiaya = $_POST['program_pembiaya'];
    $kode_pengawasan = $_POST['kode_pengawasan'];
    $kegiatan = $_POST['kegiatan'];
    $lokasi_tujuan = $_POST['lokasi_tujuan'];
    $petugas = $_POST['petugas'];
    $responden = $_POST['responden'];
    $uraian = $_POST['uraian']; 
    $pejabat_tempat = $_POST['pejabat_tempat'];


    // Proses upload foto jika ada
    $foto_kegiatan = '';
    $foto_names = [];
    if (!empty($_FILES['foto_kegiatan']['name'][0])) {
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];
        $files = $_FILES['foto_kegiatan'];
        $file_count = count($files['name']);
        for ($i = 0; $i < $file_count; $i++) {
            $file_ext = pathinfo($files['name'][$i], PATHINFO_EXTENSION);
            if (in_array($file_ext, $allowed_ext)) {
                $new_name = uniqid('foto_', true) . '.' . $file_ext;
                move_uploaded_file($files['tmp_name'][$i], '../uploads/' . $new_name);
                $foto_names[] = $new_name;
            }
        }
    }

    if (count($foto_names) > 0) {
        $foto_kegiatan = implode(',', $foto_names);
    } else {
        $foto_kegiatan = $data_laporan['foto_kegiatan'];
    }

    mysqli_query($conn,"UPDATE laporan_pengawasan SET 
        nama_petugas='$nama_petugas',
        lokasi='$lokasi',
        tgl='$tgl',
        program_pembiaya='$program_pembiaya',
        kode_pengawasan='$kode_pengawasan',
        kegiatan='$kegiatan',
        lokasi_tujuan='$lokasi_tujuan',
        petugas='$petugas',
        responden='$responden',
        uraian='$uraian',
        pejabat_tempat='$pejabat_tempat',
        foto_kegiatan='$foto_kegiatan'
        WHERE id_pengawasan='$id_laporan'
    ");
    echo "<script>window.location.href='index.php?page=riwayat_laporan_pengawasan';</script>";
    exit;
}
?>
<div class="row">
    <div class="col-xl-9 mx-auto">
        <div class="card border-top border-0 border-4 ">
            <div class="card-body">
                <div class="border p-4 rounded">
                    <div class="card-title d-flex align-items-center">
                        <div><i class="bx bxs-user me-1 font-22"></i></div>
                        <h5 class="mb-0">Edit Laporan Pengawasan</h5>
                    </div>
                    <hr />
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Nama Petugas</label>
                            <div class="col-sm-9">
                                <textarea name="nama_petugas" class="form-control" rows="2" required><?= htmlspecialchars($data_laporan['nama_petugas']) ?></textarea>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Tujuan</label>
                            <div class="col-sm-9">
                                <input type="text" name="lokasi" class="form-control" value="<?= htmlspecialchars($data_laporan['lokasi']) ?>" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Jadwal</label>
                            <div class="col-sm-9">
                                <input type="date" class="form-control" name="tgl" value="<?= htmlspecialchars($data_laporan['tgl']) ?>">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Program yang Membiayai</label>
                            <div class="col-sm-9">
                                <input type="text" name="program_pembiaya" class="form-control" value="<?= htmlspecialchars($data_laporan['program_pembiaya']) ?>" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Kode Pembebanan Anggaran</label>
                            <div class="col-sm-9">
                                <input type="text" name="kode_pengawasan" class="form-control" value="<?= htmlspecialchars($data_laporan['kode_pengawasan']) ?>" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Kegiatan</label>
                            <div class="col-sm-9">
                                <input type="text" name="kegiatan" class="form-control" value="<?= htmlspecialchars($data_laporan['kegiatan']) ?>" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Lokasi Tujuan</label>
                            <div class="col-sm-9">
                                <input type="text" name="lokasi_tujuan" class="form-control" value="<?= htmlspecialchars($data_laporan['lokasi_tujuan']) ?>" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Petugas</label>
                            <div class="col-sm-9">
                                <input type="text" name="petugas" class="form-control" value="<?= htmlspecialchars($data_laporan['petugas']) ?>" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Responden</label>
                            <div class="col-sm-9">
                                <input type="text" name="responden" class="form-control" value="<?= htmlspecialchars($data_laporan['responden']) ?>" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Uraian Kegiatan</label>
                            <div class="col-sm-9">
                                <textarea name="uraian" class="form-control" required style="resize:vertical; min-height:120px; max-height:400px;"><?= htmlspecialchars($data_laporan['uraian']) ?></textarea>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Pejabat dan Tempat yang Dikunjungi</label>
                            <div class="col-sm-9">
                                <textarea name="pejabat_tempat" class="form-control" rows="2" required><?= $data_laporan['pejabat_tempat'] ?></textarea>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Foto Kegiatan</label>
                            <div class="col-sm-9">
                                <input type="file" name="foto_kegiatan[]" class="form-control" multiple accept="image/*">
                                <small class="text-muted">Upload minimal 1, maksimal 5 foto. Jika tidak diubah, foto lama tetap digunakan.</small>
                                <?php if (!empty($data_laporan['foto_kegiatan'])): ?>
                                    <div class="mt-2">
                                        <strong>Foto lama:</strong><br>
                                        <?php foreach (explode(',', $data_laporan['foto_kegiatan']) as $foto): ?>
                                            <img src="../uploads/<?= $foto ?>" alt="Foto Kegiatan" style="max-width:100px;max-height:80px;margin-right:5px;">
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            <label class="col-sm-3 col-form-label"></label>
                            <div class="col-sm-9">
                                <input type="submit" name="submit" value="Perbaharui Laporan" class="btn btn-primary px-5">
                                <a href="index.php?page=riwayat_laporan_pengawasan" class="btn btn-secondary px-4">Batal</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
function tambahBaris() {
    var table = document.getElementById('tabel-permasalahan').getElementsByTagName('tbody')[0];
    var rowCount = table.rows.length;
    var row = table.insertRow(rowCount);
    row.innerHTML = `
        <td>${rowCount+1}</td>
        <td><textarea name="permasalahan[]" class="form-control" rows="2" required></textarea></td>
        <td><textarea name="penyelesaian[]" class="form-control" rows="2" required></textarea></td>
        <td><button type="button" class="btn btn-danger btn-sm" onclick="hapusBaris(this)">-</button></td>
    `;
}
function hapusBaris(btn) {
    var row = btn.parentNode.parentNode;
    row.parentNode.removeChild(row);
    // Update nomor urut
    var table = document.getElementById('tabel-permasalahan').getElementsByTagName('tbody')[0];
    for (var i = 0; i < table.rows.length; i++) {
        table.rows[i].cells[0].innerText = i+1;
    }
}
</script>