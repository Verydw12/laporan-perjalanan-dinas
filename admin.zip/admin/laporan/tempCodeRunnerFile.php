<?php
<!--breadcrumb-->
<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
    <div class="breadcrumb-title pe-3">Edit Laporan</div>
    <div class="ps-3">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 p-0">
                <li class="breadcrumb-item"><a href="index.php?page=dashboard"><i class="bx bx-home-alt"></i></a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Edit Laporan</li>
            </ol>
        </nav>
    </div>
</div>
<!--end breadcrumb-->
<?php
include "../conn/conn.php";
$id_laporan = $_GET['id'];
$data_laporan = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM laporan_pencacahan WHERE id_pencacahan = '$id_laporan'"));

if (isset($_POST['submit'])) {
    $nama_petugas = $_POST['nama_petugas'];
    $lokasi = $_POST['lokasi'];
    $tgl = $_POST['tgl'];
    $program_pembiaya = $_POST['program_pembiaya'];
    $kode_pengawasan = $_POST['kode_pengawasan'];
    $kegiatan = $_POST['kegiatan'];
    $lokasi_tujuan = $_POST['lokasi_tujuan'];
    $uraian = $_POST['uraian']; // array
    $hasil = $_POST['hasil']; // array
    $pejabat_tempat = $_POST['pejabat_tempat'];

    $uraian_str = implode("\n", array_map('trim', $uraian));
    $hasil_str = implode("\n", array_map('trim', $hasil));

    mysqli_query($conn,"UPDATE laporan_pencacahan SET 
        nama_petugas='$nama_petugas',
        lokasi='$lokasi',
        tgl='$tgl',
        program_pembiaya='$program_pembiaya',
        kode_pengawasan='$kode_pengawasan',
        kegiatan='$kegiatan',
        lokasi_tujuan='$lokasi_tujuan',
        uraian='$uraian_str',
        hasil='$hasil_str',
        pejabat_tempat='$pejabat_tempat'
        WHERE id_pencacahan='$id_laporan'
    ");
    echo "<script>window.location.href='index.php?page=riwayat_laporan_pencacahan';</script>";
    exit;
}

// Siapkan data lama untuk form
$uraian_list = preg_split('/\r\n|\r|\n/', $data_laporan['uraian']);
$hasil_list = preg_split('/\r\n|\r|\n/', $data_laporan['hasil']);
$max_rows = max(count($uraian_list), count($hasil_list));
?>
<div class="row">
    <div class="col-xl-9 mx-auto">
        <div class="card border-top border-0 border-4 ">
            <div class="card-body">
                <div class="border p-4 rounded">
                    <div class="card-title d-flex align-items-center">
                        <div><i class="bx bxs-user me-1 font-22"></i></div>
                        <h5 class="mb-0">Edit Laporan Pencacahan</h5>
                    </div>
                    <hr />
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Nama Petugas</label>
                            <div class="col-sm-9">
                                <textarea name="nama_petugas" class="form-control" rows="2" required><?= htmlspecialchars($data_laporan['nama_petugas']) ?></textarea>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Tujuan</label>
                            <div class="col-sm-9">
                                <input type="text" name="lokasi" class="form-control" value="<?= htmlspecialchars($data_laporan['lokasi']) ?>" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Jadwal</label>
                            <div class="col-sm-9">
                                <input type="date" class="form-control" name="tgl" value="<?= htmlspecialchars($data_laporan['tgl']) ?>">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Program yang Membiayai</label>
                            <div class="col-sm-9">
                                <input type="text" name="program_pembiaya" class="form-control" value="<?= htmlspecialchars($data_laporan['program_pembiaya']) ?>" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Kode Pembebanan Anggaran</label>
                            <div class="col-sm-9">
                                <input type="text" name="kode_pengawasan" class="form-control" value="<?= htmlspecialchars($data_laporan['kode_pengawasan']) ?>" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Kegiatan</label>
                            <div class="col-sm-9">
                                <input type="text" name="kegiatan" class="form-control" value="<?= htmlspecialchars($data_laporan['kegiatan']) ?>" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Lokasi Tujuan</label>
                            <div class="col-sm-9">
                                <input type="text" name="lokasi_tujuan" class="form-control" value="<?= htmlspecialchars($data_laporan['lokasi_tujuan']) ?>" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Uraian & Hasil</label>
                            <div class="col-sm-9">
                                <table class="table table-bordered" id="tabel-uraian">
                                    <thead>
                                        <tr>
                                            <th style="width:40px;">No.</th>
                                            <th>Uraian</th>
                                            <th>Hasil</th>
                                            <th style="width:40px;"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php for($i=0; $i<$max_rows; $i++): ?>
                                        <tr>
                                            <td><?= $i+1 ?></td>
                                            <td><textarea name="uraian[]" class="form-control" rows="2" required><?= isset($uraian_list[$i]) ? htmlspecialchars($uraian_list[$i]) : '' ?></textarea></td>
                                            <td><textarea name="hasil[]" class="form-control" rows="2" required><?= isset($hasil_list[$i]) ? htmlspecialchars($hasil_list[$i]) : '' ?></textarea></td>
                                            <td><button type="button" class="btn btn-danger btn-sm" onclick="hapusBaris(this)">-</button></td>
                                        </tr>
                                        <?php endfor; ?>
                                    </tbody>
                                </table>
                                <button type="button" class="btn btn-success btn-sm" onclick="tambahBaris()">Tambah Baris</button>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Pejabat dan Tempat yang Dikunjungi</label>
                            <div class="col-sm-9">
                                <textarea name="pejabat_tempat" class="form-control" rows="2" required><?= htmlspecialchars($data_laporan['pejabat_tempat']) ?></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <label class="col-sm-3 col-form-label"></label>
                            <div class="col-sm-9">
                                <input type="submit" name="submit" value="Perbaharui Laporan" class="btn btn-primary px-5">
                                <a href="index.php?page=riwayat_laporan_pencacahan" class="btn btn-secondary px-4">Batal</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
function tambahBaris() {
    var table = document.getElementById('tabel-uraian').getElementsByTagName('tbody')[0];
    var rowCount = table.rows.length;
    var row = table.insertRow(rowCount);
    row.innerHTML = `
        <td>${rowCount+1}</td>
        <td><textarea name="uraian[]" class="form-control" rows="2" required></textarea></td>
        <td><textarea name="hasil[]" class="form-control" rows="2" required></textarea></td>
        <td><button type="button" class="btn btn-danger btn-sm" onclick="hapusBaris(this)">-</button></td>
    `;
}
function hapusBaris(btn) {
    var row = btn.parentNode.parentNode;
    row.parentNode.removeChild(row);
    // Update nomor urut
    var table = document.getElementById('tabel-uraian').getElementsByTagName('tbody')[0];
    for (var i = 0; i < table.rows.length; i++) {
        table.rows[i].cells[0].innerText = i+1;
    }
}
</script>